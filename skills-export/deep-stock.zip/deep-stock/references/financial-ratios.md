---
name: "financial-ratios"
description: "ขั้น 4 ของ Deep Research: สร้าง tab 'Ratios' ใน Sheet 'ข้อมูลงบ TICKER' ที่คำนวณอัตราส่วนทางการเงินทั้งหมดเป็นสูตรอ้างอิงจาก tab IS/BS/CF (การเติบโต, margin, ผลตอบแทน, คุณภาพกำไร, หนี้, ประสิทธิภาพ, การจัดสรรเงิน, มูลค่า) ใช้ผ่าน deep-research หรือเมื่อผู้ใช้พิมพ์ 'คำนวณอัตราส่วน XYZ'"
---

# Financial Ratios (ขั้น 4)

## หลักการ
- **ทุกค่าเป็นสูตร** อ้างเซลล์ใน `IS`, `BS`, `CF` ห้ามพิมพ์ผลลัพธ์ที่คำนวณเอง เมื่อขั้น 3 เติมปีใหม่ Ratios จะอัปเดตเอง
- คอลัมน์ตรงกับ tab งบ: A = อัตราส่วน, B = หน่วยหรือวิธีคำนวณสั้นๆ, C ถึง L = ปีเดียวกับงบ
- ห่อทุกสูตรด้วย `IFERROR(...,"")` ให้ช่องที่ข้อมูลไม่พอแสดงเป็นว่าง ไม่ใช่ error
- ค่าเฉลี่ยงบดุล (เช่น equity เฉลี่ย) ใช้ (ปีนี้ + ปีก่อน) / 2 ปีแรกที่ไม่มีปีก่อนให้ใช้ค่าปีนั้น
- รูปแบบตัวเลข: เปอร์เซ็นต์ `0.0%`, เท่า `0.0"x"`, วัน `0`, เงิน `#,##0`

## อัตราส่วนที่ต้องมี (สูตรเขียนสำหรับคอลัมน์ D แล้วลากไปทุกปี)
**การเติบโต**
- Revenue growth `=IFERROR(IS!D2/IS!C2-1,"")`
- Operating income growth, EPS growth (สูตรแบบเดียวกัน)
- Revenue CAGR 3 ปี / 5 ปี / 10 ปี (คำนวณเฉพาะคอลัมน์ L ด้วย `(L/ปีฐาน)^(1/n)-1`)

**Margin**
- Gross margin `=IS!D4/IS!D2` | Operating margin `=IS!D8/IS!D2` | Net margin `=IS!D14/IS!D2` | FCF margin `=CF!D9/IS!D2`

**ผลตอบแทน**
- Effective tax rate `=IS!D12/IS!D11`
- NOPAT `=IS!D8*(1-อัตราภาษีแถวด้านบน)`
- Invested capital `=BS!D15+BS!D16+BS!D11+BS!D13-BS!D2-BS!D3`
- ROIC `=NOPAT / ค่าเฉลี่ย Invested capital`
- ROE `=IS!D14 / ค่าเฉลี่ย BS!15`
- ROA `=IS!D13 / ค่าเฉลี่ย BS!9`

**คุณภาพกำไร**
- FCF conversion `=CF!D9/IS!D14`
- SBC ต่อรายได้ `=IS!D18/IS!D2`
- SBC-adjusted FCF `=CF!D9-IS!D18`
- Capex ต่อรายได้ `=-CF!D3/IS!D2` | Capex ต่อ D&A `=-CF!D3/IS!D17`
- Accruals ratio `=(IS!D13-CF!D2)/ค่าเฉลี่ย BS!9`

**ความแข็งแรงทางการเงิน**
- Total debt `=BS!D11+BS!D13` | Net debt `=Total debt-BS!D2-BS!D3`
- EBITDA `=IS!D8+IS!D17` | Net debt / EBITDA
- Interest coverage `=IS!D8/IS!D9`
- Current ratio `=BS!D6/BS!D12` | Debt / Equity `=Total debt/BS!D15`

**ประสิทธิภาพ**
- DSO `=BS!D4/IS!D2*365` | DIO `=BS!D5/IS!D3*365` | DPO `=BS!D10/IS!D3*365`
- Cash conversion cycle `=DSO+DIO-DPO`
- Asset turnover `=IS!D2/ค่าเฉลี่ย BS!9`

**ต่อหุ้นและการจัดสรรเงิน**
- เปลี่ยนแปลงจำนวนหุ้น `=IS!D15/IS!C15-1` (บวก = dilution, ลบ = buyback สุทธิ)
- FCF ต่อหุ้น `=CF!D9/IS!D15`
- สัดส่วนของ FCF ที่ไป: ปันผล `=-CF!D5/CF!D9`, ซื้อหุ้นคืน `=-CF!D6/CF!D9`, ซื้อกิจการ `=-CF!D4/CF!D9`

**มูลค่า (ส่วนบนสุดของ tab แยกจากตารางรายปี)**
- เซลล์ input: ราคาหุ้น, วันที่ราคา, สกุลเงินของราคา, อัตราแลกเปลี่ยน (ถ้าสกุลเงินราคาไม่ตรงกับงบ) พร้อมแหล่ง (ใส่สีตัวอักษรน้ำเงินเพื่อบอกว่าเป็น input)
- Market cap `=ราคา × หุ้นสิ้นงวดล่าสุด` | EV `=Market cap + Net debt ล่าสุด + Minority interest`
- P/E, EV/EBIT, EV/EBITDA, FCF yield, SBC-adjusted FCF yield, Dividend yield จากปีล่าสุด (และ TTM ถ้ามี tab รายไตรมาส)

## สัญญาณเตือน (ใช้ conditional format สีแดงอ่อน)
FCF conversion ต่ำกว่า 70% สองปีติด, DSO เพิ่มเกิน 20% ในปีเดียว, SBC เกิน 10% ของรายได้, Net debt/EBITDA เกิน 3x, Interest coverage ต่ำกว่า 3x, จำนวนหุ้นเพิ่มเกิน 3% ต่อปี

## ตรวจทาน
อ่าน tab Ratios กลับด้วย grid read หาเซลล์ error และสุ่มดูว่าเซลล์ผลลัพธ์เป็นสูตร (`=...`) ไม่ใช่ตัวเลขพิมพ์เอง

## Output ให้ขั้นถัดไป
ลิงก์ tab Ratios และสรุป 5–8 บรรทัด: แนวโน้มสำคัญ, สัญญาณเตือนที่เจอ, ค่าที่ผิดปกติที่ต้องหาคำอธิบาย ขั้น 5 จะนำอัตราส่วนสำคัญไปทำตารางใน `2.Report` ส่วนที่ 2
