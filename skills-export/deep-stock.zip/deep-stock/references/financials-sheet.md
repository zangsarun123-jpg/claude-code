---
name: "financials-sheet"
description: "ขั้น 3 ของ Deep Research: ดึงงบการเงินทั้งหมดของบริษัท (งบกำไรขาดทุน งบดุล งบกระแสเงินสด ย้อนหลังสูงสุด 10 ปี และ 8 ไตรมาสล่าสุด พร้อม segment) ลง Google Sheet 'ข้อมูลงบ TICKER' ด้วยแม่แบบแถวตายตัว พร้อมแหล่งของทุกตัวเลข ใช้ผ่าน deep-research หรือเมื่อผู้ใช้พิมพ์ 'ดึงงบ XYZ'"
---

# Financials Sheet (ขั้น 3)

ตัวเลขในขั้นนี้คือฐานของทุกอย่างหลังจากนี้ ความถูกต้องสำคัญกว่าความครบ ช่องที่หาไม่ได้ให้เว้นว่างและจดไว้ ห้ามประมาณเอง

## แหล่งข้อมูล (เรียงตามลำดับที่ต้องลอง)
| ตลาด | แหล่งหลัก | วิธีดึง |
|---|---|---|
| สหรัฐ / ADR | SEC XBRL API `https://data.sec.gov/api/xbrl/companyfacts/CIK##########.json` (ต้องส่ง header `User-Agent` ที่มีชื่อและอีเมล) | ดึงด้วย Python แล้ว map แท็ก us-gaap / ifrs-full เข้ากับแถวในแม่แบบ ใช้เฉพาะค่าจาก 10-K / 20-F (form) สำหรับรายปี และ 10-Q สำหรับรายไตรมาส |
| ฮ่องกง | annual / interim report จาก HKEXnews | อ่านงบในรายงาน |
| A-share | 年报 / 半年报 จาก CNINFO | อ่านงบในรายงาน |
| สำรอง | IR ของบริษัท, stockanalysis, macrotrends หรือ WebSearch | ใช้เมื่อแหล่งหลักเข้าไม่ได้ ตัวเลขสำคัญต้องตรง 2 แหล่ง |

ถ้า network บล็อกแหล่งหลัก ให้ทำต่อด้วยแหล่งสำรอง และเขียนใน tab `Sources` ว่าใช้แหล่งสำรองเพราะอะไร

## โครงสร้าง Sheet `ข้อมูลงบ TICKER`
Sheet นี้เป็นข้อมูลเบื้องหลัง ไม่มีเลขนำหน้าชื่อ ผู้ใช้อ่านตัวเลขจากตารางใน `2.Report` ส่วนที่ 2
สร้างในโฟลเดอร์ย่อย Ticker (Drive `create_file` แบบ spreadsheet) แล้วสร้าง tab ตามลำดับนี้:

| Tab | เนื้อหา |
|---|---|
| `IS` | งบกำไรขาดทุนรายปี |
| `BS` | งบดุลรายปี |
| `CF` | งบกระแสเงินสดรายปี |
| `IS_Q`, `BS_Q`, `CF_Q` | แบบเดียวกัน 8 ไตรมาสล่าสุด |
| `Segment` | รายได้และกำไรจากการดำเนินงานแยก segment และภูมิภาค (แถวตามที่บริษัทเปิดเผย) |
| `Ratios` | สร้างโดย financial-ratios |
| `Sources` | แหล่งของแต่ละ tab และแต่ละปี, สกุลเงิน, มาตรฐานบัญชี, หมายเหตุการปรับย้อนหลัง |

**คอลัมน์ของ tab รายปี**: A = รายการ, B = หน่วย, C ถึง L = ปีเก่าสุดไปใหม่สุด (สูงสุด 10 ปี เขียนหัวคอลัมน์เป็น `'FY2016` แบบมีเครื่องหมาย ' นำหน้าเพื่อให้เป็นข้อความ) ถ้ามีข้อมูลน้อยกว่า 10 ปีให้เว้นคอลัมน์ทางซ้ายว่าง ปีล่าสุดอยู่คอลัมน์ L เสมอ

**แถวตายตัว** (ห้ามเปลี่ยนลำดับ เพราะสูตรใน Ratios อ้างเลขแถว แถวที่บริษัทไม่มีให้เว้นว่าง):

`IS` แถว 1 หัวตาราง แล้ว:
2 Revenue | 3 Cost of revenue | 4 Gross profit | 5 R&D | 6 SG&A | 7 Other operating expense | 8 Operating income | 9 Interest expense | 10 Interest income | 11 Pretax income | 12 Income tax | 13 Net income | 14 Net income attributable to parent | 15 Diluted shares | 16 Diluted EPS | 17 D&A | 18 Stock-based compensation

`BS` แถว 1 หัวตาราง แล้ว:
2 Cash & equivalents | 3 Short-term investments | 4 Accounts receivable | 5 Inventory | 6 Total current assets | 7 PP&E net | 8 Goodwill & intangibles | 9 Total assets | 10 Accounts payable | 11 Short-term debt (รวมหนี้ระยะยาวที่ครบกำหนดใน 1 ปี) | 12 Total current liabilities | 13 Long-term debt | 14 Total liabilities | 15 Equity attributable to parent | 16 Minority interest | 17 Shares outstanding (สิ้นงวด)

`CF` แถว 1 หัวตาราง แล้ว:
2 Operating cash flow | 3 Capital expenditure (ค่าลบ) | 4 Acquisitions (ค่าลบ) | 5 Dividends paid (ค่าลบ) | 6 Share repurchases (ค่าลบ) | 7 Debt issued | 8 Debt repaid (ค่าลบ) | 9 Free cash flow (สูตร `=C2+C3` ไม่พิมพ์ค่าเอง)

## กติกาตัวเลข
- หน่วยเดียวทั้ง Sheet: ล้านในสกุลเงินที่บริษัทรายงาน (เขียนใน B และใน Sources) ยกเว้น EPS และจำนวนหุ้น (ล้านหุ้น)
- ใส่ตัวเลขเป็นตัวเลข ไม่ใช่ข้อความ
- ใช้ตัวเลขตามที่รายงานในปีนั้น ถ้าบริษัทปรับย้อนหลัง (restate) ให้ใช้ฉบับล่าสุดและจดใน Sources
- บริษัทที่มีรายการพิเศษ (เช่น CEG ที่ขายลูกหนี้และบันทึก DPP ในกระแสเงินสดจากการลงทุน) ให้เพิ่มแถวพิเศษ **ต่อท้ายแถว 18/17/9** พร้อมคำอธิบายใน Sources ห้ามแทรกกลางแม่แบบ
- เขียนข้อมูลเป็นก้อน 1 tab ต่อ 1 การเรียก เพราะ Sheets API จำกัดราว 60 ครั้งต่อนาที

## ตรวจทาน
- Total assets = Total liabilities + Equity + Minority interest (คลาดได้ไม่เกิน 1%) ทุกปี
- Gross profit = Revenue − Cost of revenue ในปีที่มีทั้งสองค่า
- สุ่มเทียบ 5 ตัวเลขกับเอกสารต้นฉบับ แล้วจดผลใน Sources
- อ่านค่ากลับมาด้วย `get_values` ดูว่าไม่มีข้อความแปลกหรือ error

## Output ให้ขั้นถัดไป
ลิงก์ Sheet, ปีที่มีข้อมูล, ช่องที่ขาด และแหล่งที่ใช้
